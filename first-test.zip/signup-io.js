describe("Signup", function () {
    it('should redirect to signup page', function () {
        /*browser.setViewportSize({
            width: 1517,
            height: 730
        });*/
        const SIGNUP_BUTTON = ".button--content.-layout-h.-center-center.-space-h-4";
        browser.url("/");
        browser.waitForExist(SIGNUP_BUTTON);
        browser.leftClick(SIGNUP_BUTTON);
        /*var result = browser.execute(function () {
            var elem = document.querySelectorAll('.button--content');
            var curr = null;
            elem.forEach(function (el) {
                if (el.innerHTML.indexOf('Sign up') !== -1) {
                    el.scrollIntoView();
                    curr = el;
                }
            });
            return curr;
        });
        console.log(result);
        browser.elementIdClick(result.value.ELEMENT);*/
        browser.waitUntil(function () {
                return browser.getUrl().match(/signup$/i);
            },
            undefined,
            'Expected to be redirected to signup page after button clicking');
    });
    /*it('should scroll down', function () {
        /!* browser.execute(function () {
             var container = document.querySelector(".-margin-h-32-xxs-gt");
             container.scrollTop = container.scrollHeight;
         });*!/
        // browser.pause(5000);
        browser.waitUntil(function () {
                var elem = $(".coder-signup--button");
                return browser.elementIdDisplayed(elem.value.ELEMENT);
            },
            undefined,
            'Expected to be visible in viewport');
    });*/
    it('should click for the first time', function () {
        clicking("Email can't be empty");
    });
    it('should fill email field and click', function () {
        browser.addValue("[name = 'email']", "something");
        clicking("Full name can't be empty");
    });
    it('should fill fullName field and click', function () {
        browser.addValue("[name = 'fullName']", "something");
        clicking("Password can't be empty");
    });
    it('should fill password field and click', function () {
        browser.addValue("[name = 'password']", "something");
        clicking("You must accept the Privacy Policy and Terms of Use to complete signup");
    });
    it('should click on checkbox and click', function () {
        browser.leftClick(".privacy-and-terms--checkbox");
        clicking("Invalid email address");
    });
});


function clicking(growl_text) {
    browser.leftClick(".coder-signup--button");
    browser.waitUntil(function () {
        var growl = browser.getText(".growl-notification--content-title");
        return growl.indexOf(growl_text) != -1;
    })
}
